//
//  NotificationCell.swift
//  Alumni-Project
//
//  Created by Cahaya Ramadhan on 02/05/19.
//  Copyright © 2019 Cahaya Ramadhan. All rights reserved.
//

import UIKit

class NewCell: UITableViewCell {

    @IBOutlet weak var profileNotifNew: UIImageView!
    @IBOutlet weak var notifNameNew: UILabel!
    @IBOutlet weak var timeNotifNew: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
